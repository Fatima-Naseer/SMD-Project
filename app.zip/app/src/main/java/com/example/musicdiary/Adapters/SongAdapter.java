package com.example.musicdiary.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicdiary.Demo;
import com.example.musicdiary.R;
import java.util.ArrayList;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<Demo> data;
    private LayoutInflater inflater;

    //constructor
    public SongAdapter(Context context, ArrayList<Demo> data) {
        this.context=context;
        this.data=data;
        inflater=LayoutInflater.from(context);
    }


    //inner class
    class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView txt1;
        TextView txt2;

        private MyViewHolder(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.imageView1);
            txt1= itemView.findViewById(R.id.textView1);
            txt2= itemView.findViewById(R.id.textView2);
        }
    }//inner class ends

    @NonNull
    @Override
    public SongAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =inflater.inflate(R.layout.custom_song_row, parent, false);
        MyViewHolder myholder = new MyViewHolder(view);
        return myholder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.txt1.setText(data.get(position).song_title);
        holder.txt2.setText(data.get(position).singer);
        holder.img.setImageResource(data.get(position).img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

}
