package com.example.musicdiary.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicdiary.Adapters.AlbumAdapter;
import com.example.musicdiary.Demo;
import com.example.musicdiary.R;

import java.util.ArrayList;

public class ArtistsFragment extends Fragment {

    public static ArrayList<Demo> data =new ArrayList<>();

    public ArtistsFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        RecyclerView recyclerViewDemo = view.findViewById(R.id.recyclerViewDemo1);

        recyclerViewDemo.setLayoutManager(new GridLayoutManager(getContext(),2));

        recyclerViewDemo.setAdapter(new AlbumAdapter(getContext(),getData()));
        return view;
    }

    /*public SongsFragment newInstance() {
        SongsFragment fragment = new SongsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }*/
    //getting data
    private ArrayList<Demo> getData(){
        int img= R.drawable.headphone;

        String[] songTitles={"Beautiful Now","Believer","Faded","Paradise","You","Unbelievable",
                "Hollywood Bleeding"};
        String[] singers={"Zedd","Imagine Dragons","Alan Walker","Cold Play","James Arthur",
                "Why Don't We","Post Malone"};


        for(int i=0; i<songTitles.length; i++){
            Demo current = new Demo();
            current.setData(songTitles[i],singers[i],img);
            data.add(current);
        }
        return data;
    }
}
