package com.example.musicdiary.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicdiary.Demo;
import com.example.musicdiary.R;

import java.util.ArrayList;
import java.util.List;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.MyViewHolder> implements Filterable {
    private Context context;
    private ArrayList<Demo> data;
    private ArrayList<Demo> dataFull;
    private LayoutInflater inflater;

    //constructor
    public SearchAdapter(Context context, ArrayList<Demo> data) {
        this.context=context;
        this.data=data;
        this.dataFull= new ArrayList<>(data);
        inflater=LayoutInflater.from(context);
    }


    //inner class
    class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView txt1;
        TextView txt2;

        private MyViewHolder(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.imageView11);
            txt1= itemView.findViewById(R.id.textView15);
            txt2= itemView.findViewById(R.id.textView16);
        }
    }//inner class ends

    @NonNull
    @Override
    public SearchAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =inflater.inflate(R.layout.fragment_search, parent, false);
        MyViewHolder myholder = new MyViewHolder(view);
        return myholder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.txt1.setText(data.get(position).song_title);
        holder.txt2.setText(data.get(position).singer);
        holder.img.setImageResource(data.get(position).img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<Demo> filteredList = new ArrayList<>();
            if(charSequence == null || charSequence.length() == 0){
                filteredList.addAll(dataFull);
            }
            else{
                String filterPattern = charSequence.toString().toLowerCase().trim();
                for(Demo item : dataFull){
                    if(item.getData().toLowerCase().contains(filterPattern) || item.getDetail().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);

                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            data.clear();
            data.addAll((List) filterResults.values);
            notifyDataSetChanged();
        }
    };
}
