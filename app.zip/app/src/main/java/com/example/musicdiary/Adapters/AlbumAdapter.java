package com.example.musicdiary.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicdiary.Demo;
import com.example.musicdiary.R;

import java.util.ArrayList;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<Demo> data;
    private LayoutInflater inflater;

    //constructor
    public AlbumAdapter(Context context, ArrayList<Demo> data) {
        this.context=context;
        this.data=data;
        inflater=LayoutInflater.from(context);
    }


    //inner class
    class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imgalbum;
        TextView title;
        TextView sing;

        private MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imgalbum=itemView.findViewById(R.id.imageView5);
            title= itemView.findViewById(R.id.textView11);
            sing= itemView.findViewById(R.id.textView7);
        }
    }//inner class ends

    @NonNull
    @Override
    public AlbumAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =inflater.inflate(R.layout.custom_album_row, parent, false);
        MyViewHolder myholder = new MyViewHolder(view);
        return myholder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.title.setText(data.get(position).song_title);
        holder.sing.setText(data.get(position).singer);
        holder.imgalbum.setImageResource(data.get(position).img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}


