package com.example.musicdiary.ui.main;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.musicdiary.Fragments.AlbumsFragment;
import com.example.musicdiary.Fragments.ArtistsFragment;
import com.example.musicdiary.R;
import com.example.musicdiary.Fragments.SongsFragment;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends FragmentPagerAdapter {

    @StringRes
    private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_2};
    private final Context mContext;

    public SectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch(position) {
            case 0:
                SongsFragment t1 = new SongsFragment();
                return t1;
            case 1:
                AlbumsFragment t2 = new AlbumsFragment();
                return t2;
            case 2:
                ArtistsFragment t3 = new ArtistsFragment();
                return t3;
            default:
                return null;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch(position){
            case 0:
                return "Songs";
            case 1:
                return "Albums";
            case 2:
                return "Artists";
        }
        return null;
    }

    @Override
    public int getCount() {
        return 3;
    }
}