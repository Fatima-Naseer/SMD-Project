package com.example.musicdiary;

public class Demo {
    public String song_title;
    public String singer;
    public int img;

    public Demo() {
    }

    public void setData(String name, String x, int i) {
        this.song_title= name;
        this.singer=x;
        this.img=i;

    }

    public String getData() {
        return song_title;
    }
    public String getDetail() {
        return singer;
    }
}

