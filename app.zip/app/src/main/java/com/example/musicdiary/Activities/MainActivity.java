package com.example.musicdiary.Activities;

import android.os.Bundle;

import com.example.musicdiary.Adapters.SearchAdapter;
import com.example.musicdiary.Demo;
import com.example.musicdiary.R;
import com.example.musicdiary.nav_fragments.AboutFragment;
import com.example.musicdiary.nav_fragments.FolderFragment;
import com.example.musicdiary.nav_fragments.LibraryFragment;
import com.example.musicdiary.nav_fragments.NowPlayingFragment;
import com.example.musicdiary.nav_fragments.PlayingQueueFragment;
import com.example.musicdiary.nav_fragments.PlaylistFragment;
import com.example.musicdiary.nav_fragments.SettingFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.ToolbarWidgetWrapper;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.musicdiary.ui.main.SectionsPagerAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    public static ArrayList<Demo> data =new ArrayList<>();
    SearchAdapter adapter;
    int[] img={
            R.drawable.beautiful_now,
            R.drawable.believer,
            R.drawable.faded,
            R.drawable.paradise,
            R.drawable.you,
            R.drawable.unbelievable,
            R.drawable.hollywood
    };

    String[] songTitles={"Beautiful Now","Believer","Faded","Paradise","You","Unbelievable",
            "Hollywood Bleeding"};
    String[] singers={"Zedd","Imagine Dragons","Alan Walker","Cold Play","James Arthur",
            "Why Don't We","Post Malone"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        for(int i=0; i<songTitles.length; i++) {
            Demo current = new Demo();
            current.setData(songTitles[i], singers[i], img[i]);
            data.add(current);
        }

        adapter= new SearchAdapter(this,data);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);

        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        tabs.getTabAt(0).setIcon(R.drawable.ic_music_note_black_24dp);
        tabs.getTabAt(1).setIcon(R.drawable.ic_library_music_black_24dp);
        tabs.getTabAt(2).setIcon(R.drawable.ic_music_black_24dp);

        drawer=findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,
                R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_library:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new LibraryFragment()).commit();
                break;
            case R.id.nav_playlist:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new PlaylistFragment()).commit();
                break;
            case R.id.nav_folders:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FolderFragment()).commit();
                break;
            case R.id.nav_playingqueue:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new PlayingQueueFragment()).commit();
                break;
            case R.id.nav_nowplaying:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new NowPlayingFragment()).commit();
                break;
            case R.id.nav_settings:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new SettingFragment()).commit();
                break;
            case R.id.nav_about:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new AboutFragment()).commit();
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.drawer_menu,menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });
        return true;
    }
}